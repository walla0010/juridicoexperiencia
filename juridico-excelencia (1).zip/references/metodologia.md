# Metodologia de Análise Jurídica de Excelência

Esta referência detalha os passos para uma análise jurídica profunda e imparcial, garantindo que todos os pilares do Direito Brasileiro sejam consultados.

## 1. Pesquisa em Lei Seca
- **Constituição Federal**: Sempre iniciar verificando a constitucionalidade e princípios fundamentais.
- **Códigos e Leis Ordinárias**: Consultar a redação atualizada no site do Planalto ou legislação oficial.
- **Normas Infralegais**: Verificar decretos, instruções normativas e resoluções pertinentes ao caso.

## 2. Doutrina Dominante
- Identificar os principais autores e correntes de pensamento sobre o tema.
- Diferenciar a doutrina clássica da contemporânea, quando aplicável.
- Buscar o entendimento majoritário e as vozes dissonantes relevantes.

## 3. Precedentes e Jurisprudência
- **Tribunais Superiores (STF e STJ)**: Verificar Súmulas Vinculantes, Temas de Repercussão Geral e Recursos Repetitivos.
- **Justiça Federal (TRFs)**: Analisar o entendimento regional para casos de competência federal.
- **Justiça Estadual (TJs)**: Consultar precedentes locais, especialmente em matérias de direito privado ou público estadual/municipal.
- **Tribunais Especializados**: TST (Trabalhista), TSE (Eleitoral) e STM (Militar), conforme o caso.

## 4. Análise de Viabilidade e Estratégia
- **Caminho Conservador**: Baseado na jurisprudência pacificada e lei literal.
- **Caminho Inovador**: Teses jurídicas robustas que buscam evolução do entendimento, apontando riscos e benefícios.
- **Caminhos Alternativos**: Mediação, conciliação ou vias administrativas.

## 5. Imparcialidade e Ética
- Apresentar os fatos e o direito de forma técnica.
- Alertar o cliente sobre riscos de sucumbência ou teses temerárias.
- Manter o foco na melhor solução jurídica para o problema apresentado.
