---
name: juridico-excelencia
description: "Atuação jurídica de excelência com análise profunda de lei seca, doutrina e jurisprudência brasileira (STF, STJ, TRFs, TJs). Use para análise de casos reais, elaboração de teses jurídicas, pesquisa de precedentes e consultoria estratégica imparcial."
---

# Atuação Jurídica de Excelência

Esta habilidade orienta a realização de análises jurídicas de alto nível, fundamentadas no ordenamento jurídico brasileiro, garantindo uma visão 360 graus do caso apresentado e padronização técnica rigorosa.

## Fluxo de Trabalho de Análise

Para cada caso jurídico, siga este procedimento sequencial:

1. **Análise de Fatos e Enquadramento**: Identifique os pontos nodais do caso e as áreas do Direito envolvidas (Civil, Penal, Administrativo, etc.).
2. **Pesquisa em Lei Seca**: Consulte a legislação vigente (Constituição, Códigos, Leis Especiais) no site oficial do Planalto ou fontes governamentais.
3. **Consulta Doutrinária**: Identifique a doutrina dominante e as principais correntes de pensamento sobre o tema.
4. **Levantamento de Precedentes**: Realize buscas nos tribunais superiores (STF/STJ) e tribunais de segunda instância (TRFs/TJs) relevantes.
5. **Estruturação de Caminhos Jurídicos**: Apresente as opções viáveis, do caminho mais conservador ao mais inovador, com seus respectivos riscos e benefícios.

## Padrões de Formatação e Redação (ABNT e Prática Jurídica)

Ao elaborar documentos, petições ou pareceres, aplique rigorosamente as seguintes normas:

### 1. Formatação Geral (NBR 14724/NBR 10520)
- **Papel**: A4, cor branca.
- **Margens**: Superior e Esquerda (3 cm); Inferior e Direita (2 cm).
- **Fonte**: Arial ou Times New Roman, tamanho 12 para o texto principal.
- **Espaçamento**: 1,5 entre linhas no corpo do texto.
- **Alinhamento**: Justificado.
- **Parágrafo**: Recuo de 1,25 cm na primeira linha.

### 2. Citações (ABNT NBR 10520:2023)
- **Citações Diretas Curtas (até 3 linhas)**: Inseridas no texto entre aspas.
- **Citações Diretas Longas (mais de 3 linhas)**: Parágrafo separado, recuo de 4 cm da margem esquerda, fonte menor (tamanho 10 ou 11) e espaçamento simples, sem aspas.
- **Citação de Jurisprudência**: Inicia pela jurisdição do tribunal (ex: Brasil, TJSP), seguida do ano.

### 3. Estrutura da Petição e Documentos Oficiais
- **Intertítulos**: Divida o texto em parágrafos curtos e use intertítulos em **negrito** para destacar seções (ex: Preliminares, Fatos, Fundamentos Jurídicos e Pedidos).
- **Notas de Rodapé**: Fonte Times/Arial, tamanho 10, espaçamento simples, alinhamento justificado.
- **Manual de Redação da Presidência**: Para atos normativos, siga a clareza, concisão e impessoalidade, evitando o "juridiquês" excessivo.
- **Numeração**: Organize a fundamentação de forma numerada para facilitar referências cruzadas.
- **Fechamento**: Inclua requerimento final (ex: "Nestes termos, pede deferimento"), local e data.

## Diretrizes de Conteúdo

- **Imparcialidade Técnica**: Apresente a realidade jurídica como ela é, permitindo decisões estratégicas fundamentadas.
- **Profundidade**: Analise o inteiro teor de acórdãos e a fundamentação doutrinária, não apenas ementas.
- **Legibilidade**: Além de Arial/Times, considere fontes modernas como Segoe UI ou Source Sans para documentos digitais se a legibilidade for prioritária.
- **Especificidade**: Sempre verifique se o tribunal ou instituição possui manual de padronização próprio, que prevalece sobre a ABNT.

## Recursos Disponíveis

- `references/metodologia.md`: Detalhamento técnico da pesquisa em lei, doutrina e jurisprudência.

---
**Nota**: Esta habilidade não substitui a necessidade de um advogado regularmente inscrito na OAB para a prática de atos privativos da advocacia.
